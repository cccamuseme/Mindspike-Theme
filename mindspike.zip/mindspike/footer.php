<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Mindspike
 */

?>
</div><!-- #main-content -->

<footer>
	<div class="footer">
		<div class="container">
			<div class="row">

				<div class="footer-column-one col-xs-12 col-sm-6 col-md-3">
					<?php dynamic_sidebar( 'footer_one' ); ?>
				</div>

				<div class="footer-column-two col-xs-12 col-sm-6 col-md-3">
					<?php dynamic_sidebar( 'footer_two' ); ?>
				</div>

				<div class="clearfix visible-sm"></div>

				<div class="footer-column-three col-xs-12 col-sm-6 col-md-3">
					<?php dynamic_sidebar( 'footer_three' ); ?>
				</div>

				<div class="footer-column-four col-xs-12 col-sm-6 col-md-3">
					<?php dynamic_sidebar( 'footer_four' ); ?>
				</div>

			</div>
			<!-- /.row -->

			<br style="clear:both"/>

		</div><!-- /.container -->
	</div><!-- /.footer -->

	<div class="copyright">
		&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>, All rights reserved. <a href="https://mindspikedesign.com" target="_blank">Website by Mindspike</a>
	</div>

</footer>

<?php wp_footer(); ?>
</body>
</html>