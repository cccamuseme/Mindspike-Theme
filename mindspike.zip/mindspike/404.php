<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Mindspike
 */

get_header(); ?>

<div class="page-wrapper">
  <div class="container">

			<section class="error-404 not-found">

				<h1>404 PAGE NOT FOUND</h1>

				<div class="page-content">
					<p><?php esc_html_e( 'It looks like nothing was found at this location.', 'mindspike' ); ?></p>

					<?php get_search_form(); ?>

				</div><!-- .page-content -->
			</section><!-- .error-404 -->

	</div>
</div>

<?php
get_footer();
