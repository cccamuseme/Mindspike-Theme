<form method="get" id="searchform" action="<?php echo esc_url( home_url() ); ?>/">
	<input type="text" value="<?php the_search_query(); ?>" name="s" id="s" />
	<button type="submit">
  	<i class="fa fa-search" aria-hidden="true"></i>
  </button>
</form>