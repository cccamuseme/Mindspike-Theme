<?php

/** 
 * Template Name: Full Width
 */

get_header(); ?>

<div class="page-wrapper">
  <div class="container">
  
		<?php if (have_posts()) : while (have_posts()) : the_post();
      the_content();
    endwhile; endif; ?>
  
  </div>
</div><!-- /.page-wrapper -->

<?php get_footer(); ?>